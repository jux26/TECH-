
async function checkWhatsAppStatus(oyin, jid) {
    try {
        let [result] = await oyin.onWhatsApp(jid);
        if (!result || !result.exists) {
            return {
                isRegistered: false,
                message: "Nomor tidak terdaftar di WhatsApp.",
            };
        }
        return {
            isRegistered: true,
            message: "Terdaftar di WhatsApp",
        };
    } catch (e) {
        console.error(`Error checking WhatsApp status for ${jid}:`, e);
        return {
            isRegistered: false,
            message: "Gagal memeriksa status WhatsApp.",
        };
    }
}

let handler = async (m, { oyin, text }) => {
    try {
        // 1. Validasi input awal
        if (!text || text.trim() === "") {
            return m.reply(
                "⚠️ Masukkan nomor HP!\n\n" +
                "Contoh: .check-nomor 6281234567890"
            );
        }

        // 2. Normalisasi nomor
        let nomor = text.replace(/[^0-9]/g, "");
        if (nomor.startsWith("0")) {
            nomor = "62" + nomor.slice(1);
        } else if (!nomor.startsWith("62")) {
            nomor = "62" + nomor;
        }

        // 3. Validasi format dan panjang nomor
        if (nomor.length < 10 || nomor.length > 15 || !/^\d+$/.test(nomor)) {
            return m.reply(`⚠️ Format nomor *${text}* tidak valid. Pastikan panjangnya 10-15 digit dan hanya berisi angka.`);
        }

        let jid = nomor + "@s.whatsapp.net";

        const prefixDatabase = {
            // 🔴 TELKOMSEL
            "0811": { provider: "Telkomsel", product: "kartuHalo", kota: "Jakarta", provinsi: "DKI Jakarta" },
            "0812": { provider: "Telkomsel", product: "simPATI", kota: "Nasional", provinsi: "Indonesia" },
            "0813": { provider: "Telkomsel", product: "simPATI", kota: "Nasional", provinsi: "Indonesia" },
            "0821": { provider: "Telkomsel", product: "simPATI", kota: "Nasional", provinsi: "Indonesia" },
            "0822": { provider: "Telkomsel", product: "Loop", kota: "Nasional", provinsi: "Indonesia" },
            "0823": { provider: "Telkomsel", product: "Kartu As", kota: "Nasional", provinsi: "Indonesia" },
            "0851": { provider: "Telkomsel", product: "by.U (ex-Flexi)", kota: "Nasional", provinsi: "Indonesia" },
            "0852": { provider: "Telkomsel", product: "Kartu As", kota: "Nasional", provinsi: "Indonesia" },
            "0853": { provider: "Telkomsel", product: "Kartu As", kota: "Nasional", provinsi: "Indonesia" },

            // 🟡 INDOSAT OOREDOO HUTCHISON (IM3 & MATRIX)
            "0814": { provider: "Indosat", product: "IM3 (Broadband)", kota: "Nasional", provinsi: "Indonesia" },
            "0815": { provider: "Indosat", product: "IM3 / Mentari", kota: "Nasional", provinsi: "Indonesia" },
            "0816": { provider: "Indosat", product: "Matrix / Mentari", kota: "Nasional", provinsi: "Indonesia" },
            "0855": { provider: "Indosat", product: "Matrix", kota: "Nasional", provinsi: "Indonesia" },
            "0856": { provider: "Indosat", product: "IM3", kota: "Nasional", provinsi: "Indonesia" },
            "0857": { provider: "Indosat", product: "IM3", kota: "Nasional", provinsi: "Indonesia" },
            "0858": { provider: "Indosat", product: "IM3 / Mentari", kota: "Nasional", provinsi: "Indonesia" },

            // 🟣 TRI (3) - kini gabung Indosat
            "0895": { provider: "Tri", product: "Tri (AlwaysOn)", kota: "Nasional", provinsi: "Indonesia" },
            "0896": { provider: "Tri", product: "Tri (Regular)", kota: "Nasional", provinsi: "Indonesia" },
            "0897": { provider: "Tri", product: "Tri (Regular)", kota: "Nasional", provinsi: "Indonesia" },
            "0898": { provider: "Tri", product: "Tri (Regular)", kota: "Nasional", provinsi: "Indonesia" },
            "0899": { provider: "Tri", product: "Tri (Business)", kota: "Nasional", provinsi: "Indonesia" },

            // 🔵 XL AXIATA
            "0817": { provider: "XL Axiata", product: "XL", kota: "Nasional", provinsi: "Indonesia" },
            "0818": { provider: "XL Axiata", product: "XL", kota: "Nasional", provinsi: "Indonesia" },
            "0819": { provider: "XL Axiata", product: "XL", kota: "Nasional", provinsi: "Indonesia" },
            "0859": { provider: "XL Axiata", product: "XL", kota: "Nasional", provinsi: "Indonesia" },
            "0877": { provider: "XL Axiata", product: "XL", kota: "Nasional", provinsi: "Indonesia" },
            "0878": { provider: "XL Axiata", product: "XL", kota: "Nasional", provinsi: "Indonesia" },
            "0879": { provider: "XL Axiata", product: "XL", kota: "Nasional", provinsi: "Indonesia" },

            // 🟢 AXIS (anak XL)
            "0831": { provider: "Axis", product: "Axis", kota: "Nasional", provinsi: "Indonesia" },
            "0832": { provider: "Axis", product: "Axis", kota: "Nasional", provinsi: "Indonesia" },
            "0833": { provider: "Axis", product: "Axis", kota: "Nasional", provinsi: "Indonesia" },
            "0838": { provider: "Axis", product: "Axis", kota: "Nasional", provinsi: "Indonesia" },

            // 🟠 SMARTFREN
            "0881": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },
            "0882": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },
            "0883": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },
            "0884": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },
            "0885": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },
            "0886": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },
            "0887": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },
            "0888": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },
            "0889": { provider: "Smartfren", product: "Smartfren GSM", kota: "Nasional", provinsi: "Indonesia" },

            // ⚫ PROVIDER KHUSUS / DULU ADA
            "0890": { provider: "Net1", product: "Net1 (Ex-Sampoerna)", kota: "Nasional", provinsi: "Indonesia" },
            "0891": { provider: "Byru/Esia", product: "CDMA", kota: "Nasional", provinsi: "Indonesia" },
            "0892": { provider: "Byru/Esia", product: "CDMA", kota: "Nasional", provinsi: "Indonesia" },
            "0893": { provider: "Ceria", product: "CDMA", kota: "Nasional", provinsi: "Indonesia" },
            "0894": { provider: "Bolt", product: "4G LTE", kota: "Jakarta", provinsi: "DKI Jakarta" }
        };

        // 4. Deteksi info dari database
        const prefix4 = `0${nomor.substring(2, 5)}`;
        const defaultInfo = { provider: "Tidak Diketahui", kota: "Tidak Diketahui", provinsi: "Tidak Diketahui" };
        const { provider, kota, provinsi } = prefixDatabase[prefix4] || defaultInfo;

        // 5. Cek status WhatsApp
        const waStatus = await checkWhatsAppStatus(oyin, jid);
        if (!waStatus.isRegistered) {
            return m.reply(`❌ ${waStatus.message}\nNomor: *${nomor}*`);
        }

        // 6. Ambil informasi tambahan (Status, Tipe Akun, Foto Profil, Email, Nama Bisnis)
        let statusInfo = "-";
        let businessInfo = "WhatsApp Personal";
        let profilePic = "Tidak Tersedia";
        let emailInfo = "-";
        let businessName = "-";

        // Ambil status
        try {
            const status = await oyin.fetchStatus(jid);
            statusInfo = status?.status?.trim() || "-";
        } catch (e) {
            console.error(`Gagal mengambil status untuk ${jid}:`, e);
            statusInfo = "Tidak bisa diakses";
        }

        // Ambil informasi bisnis (termasuk email dan nama bisnis)
        try {
            const biz = await oyin.getBusinessProfile(jid);
            if (biz) {
                businessInfo = "WhatsApp Business";
                emailInfo = biz.email || "-";
                businessName = biz.business_name || "-";
            }
        } catch (e) {
            console.error(`Gagal mengambil profil bisnis untuk ${jid}:`, e);
        }

        // Ambil foto profil
        try {
            const ppUrl = await oyin.profilePictureUrl(jid, "image");
            profilePic = ppUrl ? "Ada" : "Tidak Ada";
        } catch (e) {
            console.error(`Gagal mengambil foto profil untuk ${jid}:`, e);
        }

        // 7. Waktu pengecekan
        const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

        // 8. Hasil akhir
        let teks = `
📞 *WhatsApp Number Lookup*

🆔 *Nomor:* ${nomor}
📱 *Provider:* ${provider}
🌍 *Lokasi Awal (HLR):* ${kota}, ${provinsi}
🏷️ *Jenis Akun:* ${businessInfo}
📧 *Email:* ${emailInfo}
🏢 *Nama Bisnis:* ${businessName}
✅ *Status WA:* ${waStatus.message}
💬 *Bio:* ${statusInfo}
🖼️ *Foto Profil:* ${profilePic}
⏰ *Dicek Pada:* ${waktu}

_Catatan: Info lokasi berdasarkan prefix registrasi awal dan mungkin tidak mencerminkan lokasi pengguna saat ini. Email dan nama bisnis hanya tersedia untuk akun WhatsApp Business._`;

        return m.reply(teks);

    } catch (e) {
        console.error(`Error pada command check-nomor untuk ${text}:`, e);
        return m.reply("⚠️ Terjadi kesalahan internal saat memproses permintaan.");
    }
};

handler.command = ["cek-nomor"];
handler.help = ["cek-nomor <nomor>"];
module.exports = handler;
