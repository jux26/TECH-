const settings = require("../settings");
async function aliveCommand(sock, chatId, message) {
    try {
        const message1 = `> Λ͞ctiveBot͞ 𝓲𝓼 𝓪𝓵𝓲𝓿𝓮 🫟.\n\n` +
                       `*Version:* ${settings.version}\n` +
                       `*Status:* Online\n` +
                       `*Mode:* Public\n\n` +
                       `*🫟 Features:*\n` +
                       `• 𝓖𝓻𝓸𝓾𝓹 𝓶𝓪𝓷𝓪𝓰𝓮𝓶𝓮𝓷𝓽.\n` +
                       `• 𝓐𝓷𝓽𝓲𝓵𝓲𝓷𝓴 𝓹𝓻𝓸𝓽𝓮𝓬𝓽𝓲𝓸𝓷.\n` +
                       `• 𝓕𝓾𝓷 𝓬𝓸𝓶𝓶𝓪𝓷𝓭𝓼\n` +
                       `• 𝓐𝓷𝓭 𝓶𝓪𝓷𝔂 𝓶𝓸𝓻𝓮.\n\n` +
                       `𝓣𝔂𝓹𝓮 *.menu* 𝓯𝓸𝓻 𝓯𝓾𝓵𝓵 𝓶𝓮𝓷𝓾 𝓵𝓲𝓼𝓽.`;

        await sock.sendMessage(chatId, {
            text: message1,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363422940010980@newsletter',
                    newsletterName: 'Λ͞CT͞IVɆ͟ Ɇ͟X̴P̸L͟Ø̷I̸T͞',
                    serverMessageId: -1
                }
            }
        }, { quoted: message });
    } catch (error) {
        console.error('Error in alive command:', error);
        await sock.sendMessage(chatId, { text: '> Bot is alive and running 🫟.' }, { quoted: message });
    }
}

module.exports = aliveCommand;